# Duplicate File Detection System (CLI)
CSA0307 - Data Structure capstone

Finds duplicate files in a folder (and all sub-folders) by **content**, not by name.

## Data structures and algorithm
- Hash table with chaining (4099 buckets): one `Entry` per distinct file content
- Singly linked list of paths inside each `Entry` (kept in alphabetical order)
- Recursion for folder traversal
- FNV-1a 64-bit content hash, then byte-by-byte verification (no false positives)

## Modules
- Module 1: File Scanning and Hash Indexing - `scan_dir`, `fnv1a`, `insert`
- Module 2: Duplicate Detection and Cleanup - `same_bytes`, `report`, `cleanup`

## Build
    gcc -std=gnu99 -Wall -Wextra -O2 -o dfd dfd.c      (or: make)

## Run
    ./dfd --demo testdir        create a 10-file test folder
    ./dfd testdir               scan and report (read-only)
    ./dfd testdir --delete      report, then ask before deleting [DUP] files
    ./dfd testdir --min-size 100   ignore files under 100 bytes

On Windows (MinGW/GCC) use `dfd.exe` instead of `./dfd`.

## Expected output for the demo folder
    Group 1  (49 bytes, 3 copies)
      [KEEP] testdir/backup/notes_copy.txt
      [DUP]  testdir/docs/notes.txt
      [DUP]  testdir/photos/renamed_notes.dat
    Group 2  (25 bytes, 2 copies)
      [KEEP] testdir/backup/report_old.txt
      [DUP]  testdir/docs/report.txt
    Group 3  (20000 bytes, 2 copies)
      [KEEP] testdir/backup/img1_backup.bin
      [DUP]  testdir/photos/img1.bin
    Files scanned    : 10
    Duplicate sets   : 3
    Duplicate files  : 4
    Space reclaimable: 20123 bytes
