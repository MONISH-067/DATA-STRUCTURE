/*
 * Duplicate File Detection System (CLI)
 * CSA0307 - Data Structure capstone
 *
 * Data structures : hash table with chaining, singly linked lists, recursion
 * Algorithm       : FNV-1a 64-bit content hash, then byte-by-byte verification
 * Language        : ANSI C (C99)
 *
 * Module 1 : File Scanning & Hash Indexing
 * Module 2 : Duplicate Detection & Cleanup Management
 *
 * Files are only READ, unless --delete is given and the user confirms.
 */
#define __USE_MINGW_ANSI_STDIO 1
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <dirent.h>
#ifdef _WIN32
  #include <direct.h>
  #define MKDIR(p) _mkdir(p)
  #define lstat stat
  #ifndef S_ISDIR
    #define S_ISDIR(m) (((m) & S_IFMT) == S_IFDIR)
  #endif
  #ifndef S_ISREG
    #define S_ISREG(m) (((m) & S_IFMT) == S_IFREG)
  #endif
#else
  #define MKDIR(p) mkdir((p), 0755)
#endif

#define BUCKETS   4099          /* prime number of buckets */
#define PATH_MAX_LEN 4096
#define IO_BUF    65536

typedef unsigned long long u64;

/* ---------- Data structures ---------- */

/* Linked list node: one path of a file with identical content */
typedef struct PathNode {
    char *path;
    struct PathNode *next;
} PathNode;

/* Hash table entry (chain node): one distinct file content */
typedef struct Entry {
    u64 hash;
    long long size;
    PathNode *paths;        /* sorted linked list of paths */
    int count;
    struct Entry *next;     /* chaining */
} Entry;

static Entry *table[BUCKETS];

/* statistics */
static long files_scanned = 0;
static long files_skipped = 0;
static long long wasted = 0;
static long long min_size = 1;     /* skip empty files by default */

/* ---------- Helpers ---------- */

static char *dup_str(const char *s) {
    size_t n = strlen(s) + 1;
    char *p = malloc(n);
    if (!p) { fprintf(stderr, "Out of memory\n"); exit(1); }
    memcpy(p, s, n);
    return p;
}

/* insert path keeping the list in alphabetical order */
static void add_path(Entry *e, const char *path) {
    PathNode *n = malloc(sizeof *n), **pp = &e->paths;
    if (!n) { fprintf(stderr, "Out of memory\n"); exit(1); }
    n->path = dup_str(path);
    while (*pp && strcmp((*pp)->path, path) < 0)
        pp = &(*pp)->next;
    n->next = *pp;
    *pp = n;
    e->count++;
}

/* ---------- Module 1 : File Scanning & Hash Indexing ---------- */

/* FNV-1a 64-bit hash of a file's content. Returns 0 on success. */
static int fnv1a(const char *p, u64 *hash, long long *size) {
    FILE *f = fopen(p, "rb");
    u64 h = 14695981039346656037ULL;
    static unsigned char buf[IO_BUF];
    size_t n, i;
    *size = 0;
    if (!f) return -1;
    while ((n = fread(buf, 1, sizeof buf, f)) > 0) {
        for (i = 0; i < n; i++) {
            h ^= buf[i];
            h *= 1099511628211ULL;
        }
        *size += (long long)n;
    }
    fclose(f);
    *hash = h;
    return 0;
}

/* byte-by-byte verification (buffered). Returns 1 if identical. */
static int same_bytes(const char *a, const char *b) {
    FILE *fa = fopen(a, "rb"), *fb = fopen(b, "rb");
    static unsigned char ba[IO_BUF], bb[IO_BUF];
    int ok = (fa && fb);
    while (ok) {
        size_t na = fread(ba, 1, sizeof ba, fa);
        size_t nb = fread(bb, 1, sizeof bb, fb);
        if (na != nb || memcmp(ba, bb, na) != 0) ok = 0;
        else if (na == 0) break;
    }
    if (fa) fclose(fa);
    if (fb) fclose(fb);
    return ok;
}

/* Module 2 core: hash-table insert + duplicate detection */
static void insert(const char *path) {
    long long size;
    u64 h;
    unsigned idx;
    Entry *e;

    if (fnv1a(path, &h, &size) != 0) {
        fprintf(stderr, "  [skip] cannot read: %s\n", path);
        files_skipped++;
        return;
    }
    if (size < min_size) { files_skipped++; return; }

    files_scanned++;
    idx = (unsigned)(h % BUCKETS);
    for (e = table[idx]; e; e = e->next)
        if (e->hash == h && e->size == size &&
            same_bytes(e->paths->path, path)) {
            add_path(e, path);
            wasted += size;
            return;
        }
    e = calloc(1, sizeof *e);
    if (!e) { fprintf(stderr, "Out of memory\n"); exit(1); }
    e->hash = h;
    e->size = size;
    e->next = table[idx];
    table[idx] = e;
    add_path(e, path);
}

/* recursive directory traversal */
static void scan_dir(const char *dir) {
    DIR *d = opendir(dir);
    struct dirent *de;
    char full[PATH_MAX_LEN];
    struct stat st;

    if (!d) { fprintf(stderr, "  [skip] cannot open folder: %s\n", dir); return; }
    while ((de = readdir(d)) != NULL) {
        if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, "..")) continue;
        if (snprintf(full, sizeof full, "%s/%s", dir, de->d_name) >= (int)sizeof full)
            continue;
        if (lstat(full, &st) != 0) continue;
        if (S_ISDIR(st.st_mode))      scan_dir(full);   /* recursion */
        else if (S_ISREG(st.st_mode)) insert(full);
    }
    closedir(d);
}

/* ---------- Module 2 : Report & Cleanup ---------- */

static int cmp_groups(const void *a, const void *b) {
    const Entry *x = *(Entry *const *)a, *y = *(Entry *const *)b;
    if (x->count != y->count) return y->count - x->count;      /* most copies first */
    if (x->size != y->size) return x->size < y->size ? -1 : 1; /* then smaller size */
    return strcmp(x->paths->path, y->paths->path);
}

static void free_all(void) {
    int i;
    for (i = 0; i < BUCKETS; i++) {
        Entry *e = table[i];
        while (e) {
            Entry *nx = e->next;
            PathNode *p = e->paths;
            while (p) { PathNode *pn = p->next; free(p->path); free(p); p = pn; }
            free(e);
            e = nx;
        }
        table[i] = NULL;
    }
}

/* returns the number of files deleted */
static int cleanup(Entry **groups, int ngroups) {
    int i, deleted = 0, dups = 0;
    char ans[16];
    for (i = 0; i < ngroups; i++) dups += groups[i]->count - 1;
    printf("\nDelete %d duplicate file(s) marked [DUP]? The [KEEP] copies stay. (y/N): ", dups);
    fflush(stdout);
    if (!fgets(ans, sizeof ans, stdin) || (ans[0] != 'y' && ans[0] != 'Y')) {
        printf("Cleanup cancelled. No file was changed.\n");
        return 0;
    }
    for (i = 0; i < ngroups; i++) {
        PathNode *p;
        for (p = groups[i]->paths->next; p; p = p->next) {
            if (remove(p->path) == 0) { printf("  deleted: %s\n", p->path); deleted++; }
            else fprintf(stderr, "  failed : %s\n", p->path);
        }
    }
    printf("Deleted %d file(s).\n", deleted);
    return deleted;
}

static void report(int do_delete) {
    Entry **groups = NULL, *e;
    int i, ngroups = 0, cap = 0;
    long dup_files = 0;

    for (i = 0; i < BUCKETS; i++)
        for (e = table[i]; e; e = e->next)
            if (e->count > 1) {
                if (ngroups == cap) {
                    cap = cap ? cap * 2 : 16;
                    groups = realloc(groups, cap * sizeof *groups);
                    if (!groups) { fprintf(stderr, "Out of memory\n"); exit(1); }
                }
                groups[ngroups++] = e;
            }
    if (ngroups) qsort(groups, ngroups, sizeof *groups, cmp_groups);

    for (i = 0; i < ngroups; i++) {
        PathNode *p;
        printf("\nGroup %d  (%lld bytes, %d copies)\n", i + 1, groups[i]->size, groups[i]->count);
        for (p = groups[i]->paths; p; p = p->next)
            printf("  %s %s\n", p == groups[i]->paths ? "[KEEP]" : "[DUP] ", p->path);
        dup_files += groups[i]->count - 1;
    }
    if (!ngroups) printf("\nNo duplicate files found.\n");

    printf("\nFiles scanned    : %ld\n", files_scanned);
    printf("Duplicate sets   : %d\n", ngroups);
    printf("Duplicate files  : %ld\n", dup_files);
    printf("Space reclaimable: %lld bytes\n", wasted);
    if (files_skipped) printf("Files skipped    : %ld (empty or unreadable)\n", files_skipped);

    if (do_delete && ngroups) cleanup(groups, ngroups);
    free(groups);
}

/* ---------- Demo folder generator ---------- */

static void write_file(const char *path, const char *text, long repeat_bytes) {
    FILE *f = fopen(path, "wb");
    long i;
    if (!f) { fprintf(stderr, "cannot create %s\n", path); return; }
    if (text) fputs(text, f);
    for (i = 0; i < repeat_bytes; i++) fputc((int)((i * 7 + 3) % 251), f);
    fclose(f);
}

static void make_demo(const char *root) {
    char p[PATH_MAX_LEN];
    const char *notes49 = "Hash tables and linked lists find duplicates....\n";
    const char *rep25  = "Quarterly report: 100 ok\n";
    const char *rep25b = "Quarterly report: 101 ok\n";   /* near-identical, 1 byte differs */
    MKDIR(root);
    snprintf(p, sizeof p, "%s/docs", root);    MKDIR(p);
    snprintf(p, sizeof p, "%s/backup", root);  MKDIR(p);
    snprintf(p, sizeof p, "%s/photos", root);  MKDIR(p);

#define W(rel, txt, n) do { snprintf(p, sizeof p, "%s/%s", root, rel); write_file(p, txt, n); } while (0)
    W("docs/a.txt",              "File A: unique content\n", 0);
    W("docs/notes.txt",          notes49, 0);
    W("docs/report.txt",         rep25, 0);
    W("docs/report_v2.txt",      rep25b, 0);
    W("backup/b.txt",            "File B: another unique file\n", 0);
    W("backup/notes_copy.txt",   notes49, 0);
    W("backup/report_old.txt",   rep25, 0);
    W("backup/img1_backup.bin",  NULL, 20000);
    W("photos/img1.bin",         NULL, 20000);
    W("photos/renamed_notes.dat", notes49, 0);
#undef W
    printf("Demo folder created: %s (10 files)\n", root);
}

/* ---------- main ---------- */

static void usage(const char *prog) {
    printf("Duplicate File Detection System\n\n"
           "Usage:\n"
           "  %s <folder> [options]\n"
           "  %s --demo <folder>      create a 10-file test folder\n\n"
           "Options:\n"
           "  --delete       after the report, offer to delete [DUP] files (asks first)\n"
           "  --min-size N   ignore files smaller than N bytes (default 1, skips empty files)\n"
           "  -h, --help     show this help\n", prog, prog);
}

int main(int argc, char **argv) {
    const char *folder = NULL;
    int i, do_delete = 0;
    struct stat st;

    if (argc >= 3 && !strcmp(argv[1], "--demo")) { make_demo(argv[2]); return 0; }

    for (i = 1; i < argc; i++) {
        if (!strcmp(argv[i], "--delete")) do_delete = 1;
        else if (!strcmp(argv[i], "--min-size") && i + 1 < argc) min_size = atoll(argv[++i]);
        else if (!strcmp(argv[i], "-h") || !strcmp(argv[i], "--help")) { usage(argv[0]); return 0; }
        else if (!folder) folder = argv[i];
        else { usage(argv[0]); return 1; }
    }
    if (!folder) { usage(argv[0]); return 1; }
    if (stat(folder, &st) != 0 || !S_ISDIR(st.st_mode)) {
        fprintf(stderr, "Error: '%s' is not a readable folder.\n", folder);
        return 1;
    }

    printf("Scanning: %s\n", folder);
    scan_dir(folder);
    report(do_delete);
    free_all();
    return 0;
}
